import os
from flask import Flask, render_template, request
import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt

__author__ = 'ibininja'

app = Flask(__name__)

APP_ROOT = os.path.dirname(os.path.abspath(__file__))


@app.route("/")
def index():
    return render_template("upload.html")

@app.route("/upload", methods=['GET', 'POST'])
def upload():
    if request.method == "POST":
        Technique = request.form.get("Technique", None)
        print(Technique)
    target = os.path.join(APP_ROOT, 'static/')
    print(target)

    if not os.path.isdir(target):
        os.mkdir(target)


    var1 = request.files.getlist("file")
    filename = var1[0].filename
    destination = "/".join([target, filename])  # Specify name or put 'filename' as second condition
    print(destination)
    print(filename)
    var1[0].save(destination)
    img = cv.imread(destination)


    var2 = request.files.getlist("file2")
    filename2 = var2[0].filename
    destination2 = "/".join([target, filename2])  # Specify name or put 'filename' as second condition
    print(destination2)
    print(filename2)
    var2[0].save(destination2)
    img2 = cv.imread(destination2)

    if Technique == 'Grab and Cut Algorithm':
        # Grab and Cut Algorithm ---------------
        mask = np.zeros(img.shape[:2], np.uint8)

        bgdModel = np.zeros((1, 65), np.float64)
        fgdModel = np.zeros((1, 65), np.float64)

        rect = (1, 1, 2000, 2000)
        cv.grabCut(img, mask, rect, bgdModel, fgdModel, 5, cv.GC_INIT_WITH_RECT)

        mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
        img = img * mask2[:, :, np.newaxis]
        # --------------------------------------
    elif Technique == 'Canny Edge Detection':
        # Canny Edge Detection ---------------
        img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)  # Needed to begin
        img = cv.Canny(img, 100, 200)  # minVal/maxVal
        # --------------------------------------
    elif Technique == 'Laplacian Transformation':
        #  Laplacian Transformation ----------------
        img = cv.Laplacian(img, cv.CV_64F)
        # -------------------------------------
    elif Technique == 'Edge Preserving Filter':
        # Edge Preserving Filter -------------------
        img = cv.edgePreservingFilter(img, flags=1, sigma_s=60, sigma_r=0.4)
        # ------------------------------------------
    elif Technique == 'Detail Enhancing Filter':
        # Detail Enhancing Filter ------------------
        img = cv.detailEnhance(img, sigma_s=10, sigma_r=0.15)
        # ------------------------------------------
    elif Technique == 'Brute-Force Matcher (ORB)':
        # Brute-Force Matcher (ORB) ----------------
        img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        img2 = cv.cvtColor(img2, cv.COLOR_BGR2GRAY)
        orb = cv.ORB_create()
        kp1, des1 = orb.detectAndCompute(img, None)  # key points and destinations
        kp2, des2 = orb.detectAndCompute(img2, None)  # key points and destinations
        bf = cv.BFMatcher(cv.NORM_HAMMING, crossCheck=True)  # cross check true: less but better features/comparisons
        matches = bf.match(des1, des2)
        matches = sorted(matches, key=lambda x: x.distance)
        img = cv.drawMatches(img, kp1, img2, kp2, matches[:15], None, flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
        # ------------------------------------------
    elif Technique == 'Mean Adaptive Thresholding':
        img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        img = cv.adaptiveThreshold(img, 255, cv.ADAPTIVE_THRESH_MEAN_C, cv.THRESH_BINARY, 199, 0)
    elif Technique == 'Gaussian Adaptive Thresholding':
        img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        img = cv.adaptiveThreshold(img, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C, cv.THRESH_BINARY, 199, 5)
    elif Technique == 'K means':
        Z = img.reshape((-1, 3))
        # convert to np.float32
        Z = np.float32(Z)
        # define criteria, number of clusters(K) and apply kmeans()
        criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 10, 1.0)
        K = 4  # Change 2, 4, 8
        ret, label, center = cv.kmeans(Z, K, None, criteria, 10, cv.KMEANS_RANDOM_CENTERS)
        # Now convert back into uint8, and make original image
        center = np.uint8(center)
        res = center[label.flatten()]
        res2 = res.reshape((img.shape))
        img = res2
    destination3 = destination[0:-4] + '_final.png'
    cv.imwrite(destination3, img)
    filename3 = filename[0:-4] + '_final.png'
    return render_template("complete.html", image_name=filename, image_name2=filename2, image_name3=filename3)

if __name__ == "__main__":
    app.run(port=4555, debug=True)
